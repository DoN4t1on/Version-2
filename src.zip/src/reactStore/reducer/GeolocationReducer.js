import * as ActionList from '../actions/ActionsList';
const initialState = {
  isLoading: false,

  locationName: '',
  lat: '',
  long: '',
};
// eslint-disable-next-line
export default (state = initialState, { type, payload }) => {
  switch (type) {
    case ActionList.SET_CITY_NAME:
      return {
        ...state,

        locationName: payload,
      };

    case ActionList.SET_LAT_LONG:
      return {
        ...state,

        lat: payload.lat,
        long: payload.long,
      };

    default:
      return state;
  }
};
