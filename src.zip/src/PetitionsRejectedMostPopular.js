
import { Petition } from "./Petition";
import { NavbarBottom } from "./NavbarBottom";
import Spielplatz from "./img/playground_petition.jpg";
import Parkbank from "./img/bench.jpg";
import Sportplatz from "./img/sportsfield.jpg";
import Radweg from "./img/bikeway.jpg";
import { Link } from "react-router-dom";
import Header from './components/Header';

export const PetitionsRejectedMostPopular = () => {


	return (
    <div>
      <Header />
      <div className='campaigns'>
        <Petition
          titel='Spielplatz'
          beschreibung='Toller neuer Spielplatz'
          bild={Spielplatz}
        />
        <Petition
          titel='Parkbank'
          beschreibung='Krasse neue Parkbank im Nordpark'
          bild={Parkbank}
        />
        <Petition
          titel='Sportplatz'
          beschreibung='Mega nicer neuer Sportplatz'
          bild={Sportplatz}
        />
        <Petition
          titel='Fahrradweg'
          beschreibung='Bester Fahrradweg nach Mühlheim'
          bild={Radweg}
        />
      </div>
      <NavbarBottom
        classstart='under-navitem-selected'
        classsearch='under-navitem-unselected'
        classactivity='under-navitem-unselected'
        classprofile='under-navitem-unselected'
      />
    </div>
  );

}