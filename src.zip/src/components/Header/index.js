import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Geocode from 'react-geocode';
import { mapAPiKey } from '../../config/config';
import { useDispatch, useSelector } from 'react-redux';
import { SET_City, SET_LatLong } from '../../reactStore/actions/Actions';
function Header() {
  const dispatch = useDispatch();
  /////const [locationName, setlocationName] = useState('Standort');
  Geocode.setApiKey(mapAPiKey);

  const { locationName } = useSelector((state) => state.Geo);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(function (position) {
      let payload = {
        lat: position.coords.latitude,
        long: position.coords.longitude,
      };

      dispatch(SET_LatLong(payload));

      Geocode.fromLatLng(
        position.coords.latitude,
        position.coords.longitude
        /// 50.9697143,
        //6.9679737
      ).then(
        (response) => {
          var city = '';
          var state = '';
          var country = '';
          var zipcode = '';

          var address_components = response.results[0].address_components;

          for (var i = 0; i < address_components.length; i++) {
            if (
              address_components[i].types[0] ===
                'administrative_area_level_1' &&
              address_components[i].types[1] === 'political'
            ) {
              state = address_components[i].long_name;
            }
            if (
              address_components[i].types[0] === 'locality' &&
              address_components[i].types[1] === 'political'
            ) {
              city = address_components[i].long_name;
            }

            if (
              address_components[i].types[0] === 'postal_code' &&
              zipcode == ''
            ) {
              zipcode = address_components[i].long_name;
            }

            if (address_components[i].types[0] === 'country') {
              country = address_components[i].long_name;
            }
          }

          ///// const address = response.results[0].formatted_address;

          dispatch(SET_City(city));
          ///  setlocationName(city);
        },
        (error) => {
          console.error(error);

          dispatch(SET_City('Standort'));

          let payload = {
            lat: 'false',
            long: 'false',
          };

          dispatch(SET_LatLong(payload));
        }
      );

      ///   console.log('Latitude is :', position.coords.latitude);
      ///console.log('Longitude is :', position.coords.longitude);
    });
  }, []);

  return (
    <div>
      <div id='header'>
        <p className='location' id='location'>
          <Link to='/filter'>
            {locationName}{' '}
            <img id='filter' src={require('../../img/funnel-fill.svg')} />{' '}
          </Link>{' '}
        </p>

        <p className='menu1 small-headlines'>
          {' '}
          <Link className='strong' to='/'>
            Petitionen
          </Link>{' '}
          | <Link to='/crowdfunding'>Crowdfunding</Link>
        </p>
        <p className='menu2 small-headlines '>
          {' '}
          <Link to='/' className='strong'>
            Aktiv{' '}
          </Link>
          |
          <Link to='/petitionen-akzeptiert' className=''>
            {' '}
            Akzeptiert{' '}
          </Link>
          |{' '}
          <Link to='/petitionen-abgelehnt' className=''>
            Abgelehnt{' '}
          </Link>{' '}
        </p>
        <p className='last-menu small-headlines'>
          {' '}
          <Link to='/' className='strong'>
            Am nächsten{' '}
          </Link>
          |{' '}
          <Link to='/petitionen-aktiv-neuste' className=''>
            {' '}
            Neuste{' '}
          </Link>
          |{' '}
          <Link to='/petitionen-aktiv-am-beliebtesten' className=''>
            {' '}
            Beliebtest
          </Link>{' '}
        </p>
      </div>
    </div>
  );
}

export default Header;
