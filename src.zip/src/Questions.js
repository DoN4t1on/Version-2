
import { NavbarBottom } from "./NavbarBottom";

import { Link } from "react-router-dom";

export const Questions = () => {


	return (
		<div >

			<br /><br />
			<button className="btn btn-success btn-lg button"   >Frage stellen</button>



			<NavbarBottom classstart="under-navitem-selected" classsearch="under-navitem-unselected" classactivity="under-navitem-unselected" classprofile="under-navitem-unselected" />
		</div>
	)
}