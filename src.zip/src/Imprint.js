




export const Imprint = () => {




	return (
    <div>
      <br />
      <h3>
        {' '}
        <strong> Impressum </strong>{' '}
      </h3>
      <br />
      LocalPetition UG (haftungsbeschränkt) <br />
      Am Nordpark 106 <br />
      50733 Köln, Deutschland <br /> <br />
      Gründer und Geschäftsführer: Felix Scherf <br />
      <br />
      Telefon: +49 1577 9683734 <br />
      E-Mail: info@lokalpetition.de <br /> <br />
      Handelsregister: HRB 106411 <br />
      USt-ID: DE351686821 <br />
      <br />
      Zuständige Aufsichtsbehörde: <br /> <br />
      Amtsgericht Köln <br />
      Luxemburger Str. 101 <br />
      50939 Köln, Deutschland
      <br />
      <br />
      <strong>
        Urheberrecht © 2021-2022 LocalPetition UG (haftungsbeschränkt). <br />{' '}
        Alle Rechte vorbehalten.{' '}
      </strong>
      <br /> <br />
    </div>
  );

}
