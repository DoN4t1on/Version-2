
import { NavbarBottom } from "./NavbarBottom";
import { Comment } from "./Comment";
import { useState } from "react";
import { Link, useParams } from 'react-router-dom';
import React, { useState } from 'react';
import { localStorageData, Logout } from './services/auth/localStorageData';
import ErrorService from './services/formatError/ErrorService';
import userServices from './services/httpService/userAuth/userServices';
import { useMutation, useQuery } from 'react-query';
import { toast } from 'react-toastify';
import { ImageEndPoint } from './config/config';

export const Comments = () => {
  const { Id } = useParams();

  const UploadNewComment = useMutation(
    (NewComment) =>
      userServices.commonPostService('/post/uploadComment', NewComment),
    {
      onError: (error) => {
        toast.error(ErrorService.uniformError(error));
      },
      onSuccess: (res) => {
        getComments.refetch();
        /// navigate('/');
      },
    }
  );

  const [allComments, setallComments] = React.useState([]);

  const getComments = useQuery(
    'getComments',
    () => userServices.commonGetService(`/post/getComments/${Id}`),
    {
      refetchOnWindowFocus: false,
      onError: (error) => {
        toast.error(ErrorService.uniformError(error));
      },
      onSuccess: (res) => {
        console.log(res.data.data);
        setallComments(res.data.data);
      },
    }
  );
  const [amount, setAmount] = useState();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (localStorageData('_id')) {
      UploadNewComment.mutate({
        userId: localStorageData('_id'),
        postId: Id,
        own_experience: amount,
      });
      setAmount('');
    } else {
      toast.error('Bitte melden Sie sich zuerst an');
    }
  };

  return (
    <div>
      <div className='casual-header-div'>
        <div className='comments-header'>
          <h4>Kommentare ({allComments.length})</h4>
          <p>
            <Link to='/neuste-kommentare'>
              <strong>Neuste</strong>
            </Link>{' '}
            | <Link to='/beliebteste-kommentare'>Beliebtest</Link>
          </p>
        </div>
      </div>
      <div className='comment-menu'>
        {allComments.map((item) => (
          <Comment item={item} />
        ))}
      </div>
      <form onSubmit={handleSubmit}>
        <div className='comment-bar'>
          <input
            value={amount}
            type='text'
            className='comment-input'
            placeholder='Kommentieren'
            onChange={(e) => setAmount(e.target.value)}
            required
          />
          <button type='submit' className='btn btn-ghost-light comment-button'>
            <img
              className='comment-image'
              src={require('./img/send-comment.svg')}
            />
          </button>
        </div>
      </form>

      <NavbarBottom
        classstart='under-navitem-selected'
        classsearch='under-navitem-unselected'
        classactivity='under-navitem-unselected'
        classprofile='under-navitem-unselected'
      />
    </div>
  );
};