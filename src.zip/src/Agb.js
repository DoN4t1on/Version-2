import React from 'react';
import Header from './components/Header';

function Agb() {
  return (
    <div className=''>
      <Header />
      <br />
      <br />
      <br />
      <div className='agb-styl'>
        <p>
          Please take that text for the AGB: Allgemeine
          Gesch&auml;ftsbedingungen
        </p>
        <p>Ver&ouml;ffentlicht am 20. Mai 2022</p>
        <p>Datum des Inkrafttretens: 20. Mai 2022</p>
        <p>Kontakt</p>
        <p>Telefon: +49 1577 9683734</p>
        <p>
          E-Mail:{' '}
          <a href='mailto:info@lokalpetition.de'>info@lokalpetition.de</a>
        </p>
        <ol>
          <li>Wesen des Angebotes</li>
          <li>
            <br />
          </li>
          <li>
            Vielen Dank f&uuml;r dein Interesse an Lokalpetition! Unter der
            Domain lokalpetition.de bietet die LocalPetition UG
            (haftungneschr&auml;nkt), vertreten durch Felix Scherf (im
            Folgenden: &bdquo;Lokalpetition&ldquo;, oder &bdquo;wir&ldquo;) eine
            auf B&uuml;rgerbeteiligung ausgerichtete Website mit vorwiegend
            nutzergenerierten Inhalten. Lokalpetition stellt hierzu die
            technische Plattform.Eigene Inhalte bietet Lokalpetition auf
            &acute;Lokalpetition.de in der Regel nicht an. Lokalpetition wird
            hinsichtlich der Inhalte stets nur als Vermittler t&auml;tig.
            F&uuml;r fremde Inhalte &uuml;bernimmt Lokalpetition keine Haftung.
            Lokalpetition kann nicht f&uuml;r eine gegebenenfalls angegebene
            Identit&auml;t eines Nutzers einstehen. Lokalpetition beh&auml;lt
            sich vor, die angebotenen Dienste zu &auml;ndern, einzustellen oder
            neue Dienste anzubieten.
          </li>
        </ol>
        <p>
          Die vorliegenden Allgemeinen Gesch&auml;ftsbedingungen
          (&bdquo;AGB&ldquo;) regeln deinen Zugriff auf Lokalpetition.de. In
          unserer Datenschutzrichtlinie wird erl&auml;utert, wie wir deine Daten
          erheben und verwenden, w&auml;hrend hier deine Pflichten hinsichtlich
          der Nutzung von Lokalpetition dargelegt werden. Durch die
          Registrierung erkl&auml;rst du dich mit diesen AGB und unserer
          Datenschutzrichtlinie einverstanden.
        </p>
        <p>Registrierung</p>
        <p>
          Jeder Nutzer, der aktiv an der Kommunikation teilnehmen m&ouml;chte
          (sich mit anderen Nutzern austauschen, Inhalte einstellen m&ouml;chte,
          f&uuml;r Ideen voten m&ouml;chte etc.), muss sich hierzu bei
          Lokalpetition registrieren. Durch die Registrierung entstehen dem
          Nutzer keine Kosten. Die Registrierung bei Lokalpetition erfolgt unter
          Lokalpetition.de. Es wird ein frei w&auml;hlbarer Nutzername von dem
          Nutzer ben&ouml;tigt. Der Nutzer w&auml;hlt bei seiner Registrierung
          ein Passwort. Er verpflichtet sich, dieses Passwort geheim zu halten.
          Kein Nutzer darf mehr als ein Nutzerprofil registrieren.
        </p>
        <p>Verf&uuml;gbarkeit und Nutzung des Angebotes</p>
        <p>
          Grunds&auml;tzlich steht die Nutzung jeder nat&uuml;rlichen und
          gesch&auml;ftsf&auml;higen Person, die gewillt ist sich an diese
          Nutzungsbedingungen zu halten und zu den Themen und Inhalten
          konstruktiv beizutragen, frei.Der Zugang zum Angebot und dessen
          Nutzung, kann jedoch nicht rechtlich beansprucht werden, wir behalten
          uns in jedem Fall unsere Zustimmung vor.Eine uneingeschr&auml;nkte
          Verf&uuml;gbarkeit des Angebots f&uuml;r die Nutzer ist technisch
          nicht zu leisten, da unser Angebot Zugriff auf Telekommunikationsnetze
          und -verbindungen anderer Netzbetreiber und anderer Diensteanbieter
          voraussetzt, auf deren Leistungen wir keinen Einfluss haben.Soweit wir
          Einfluss auf Unterbrechungen, z.B. notwendige Ma&szlig;nahmen (wie
          Pflege- und Wartungsarbeiten an Software) haben, sind wir bem&uuml;ht
          Unterbrechungen des Angebotes zeitlich so kurz wie m&ouml;glich zu
          halten und diese ggf.auch anzuk&uuml;ndigen.
        </p>
        <p>Nutzerpflichten und besondere Nutzungsbedingungen</p>
        <p>
          Grundlage der Nutzung, sind die nachfolgenden Bestimmungen, die
          wesentliche Vertragspflichten der Nutzer enthalten:
        </p>
        <p>
          4.1 Unzul&auml;ssige Inhalte, kommerzielle Werbung, unerlaubte
          Nutzungsweisen, Links
        </p>
        <p>
          Wir weisen ausdr&uuml;cklich darauf hin, dass folgende
          Nutzungshandlungen oder Inhalte nicht zul&auml;ssig sind und wir
          bereits bei einem ersten Zuwiderhandeln neben der Entfernung des
          Inhalts bzw.Beitrags weitere Konsequenzen bis zu einer sofortigen
          Sperrung des Nutzers f&uuml;r alle Dienste ziehen werden:
        </p>
        <p>
          Alle Beitr&auml;ge, T&auml;tigkeiten und Handlungen, die
          gesetzeswidrige, insbesondere beleidigende, pornographische oder sonst
          gegen Jugendschutzbestimmungen versto&szlig;ende Handlungen darstellen
          oder diese verherrlichen, sowie alle Beitr&auml;ge, in denen
          nat&uuml;rliche oder juristische Personen sonst in ihrer Ehre bzw.dem
          gesch&auml;ftlichen Ansehen herabgesetzt oder ihr gesch&auml;ftlicher
          oder sonstiger Ruf gesch&auml;digt wird.
        </p>
        <p>
          Das Offenlegen oder zug&auml;nglich machen von pers&ouml;nlichen
          Zugangsdaten zu Lokalpetition, seien es eigene Daten oder fremde
          Daten.Die Verletzung von Urheber- oder Markenrechten Dritter,
          insbesondere im Falle eines Versto&szlig;es gegen die nachfolgende
          Ziffer 4.2 Jede Form von Diskriminierung anderer Menschen sowie
          sonstige schwerwiegende Verst&ouml;&szlig;e gegen die Netiquette.
        </p>
        <p>
          Das Setzen von Links zu anderen Seiten oder Diensten, die
          gesetzeswidrigen, beleidigenden oder pornografischen Inhalt oder sonst
          unerw&uuml;nschte Inhalte aufweisen sowie jede Form von Werbung oder
          kommerzieller Nutzung ohne unsere ausdr&uuml;ckliche vorherige
          Zustimmung.
        </p>
        <p>
          Das Setzen von Links zu anderen Seiten oder Diensten, die
          gesetzeswidrigen, beleidigenden oder pornografischen Inhalt oder sonst
          unerw&uuml;nschte Inhalte aufweisen sowie jede Form von Werbung oder
          kommerzieller Nutzung ohne unsere ausdr&uuml;ckliche vorherige
          Zustimmung.
        </p>
        <p>
          Das automatische Auslesen der auf unserer Seite befindlichen Daten
          sowie der Aufbau eigener Suchsysteme, Dienste und Verzeichnisse unter
          Zuhilfenahme der auf Lokalpetition.de abrufbaren Inhalte sowie das
          massenhafte Erstellen von inhaltsgleichen Beitr&auml;gen und/oder
          Antworten, auch Crosspostings, also das Posten des gleichen Beitrags
          in mehreren Foren.Dies gilt auch f&uuml;r Kurzmitteilungen.
        </p>
        <p>
          Ferner das Versenden von Kettenmails bzw.-briefen per Mail, jegliche
          Durchf&uuml;hrung von Strukturvertrieb bzw.
          -vertriebsunterst&uuml;tzung, auch sog.Multi-level-marketing.Das
          Hochladen von Software, Skripten, Dateien und sonstigen
          Mechanismen/Techniken, die dazu geeignet sind, Lokalpetition.de oder
          dessen User, deren Computer, die Server von Lokalpetition.de oder die
          auf den Rechnern der User oder den Servern von Lokalpetition.de
          verwendete Software, auszuspionieren, zu attackieren, lahm zu legen
          oder in sonstiger Form zu beeintr&auml;chtigen oder zu einer
          Beeintr&auml;chtigung Beihilfe zu leisten.
        </p>
        <p>
          Unerw&uuml;nscht sind au&szlig;erdem folgende Nutzungshandlungen und
          Inhalte:
        </p>
        <p>
          Beitr&auml;ge oder Kommunikation mit politischen oder religi&ouml;sen
          Inhalten.
        </p>
        <p>
          Beitr&auml;ge oder Kommunikation mit erotischem oder sexuell
          gepr&auml;gten Inhalt.
        </p>
        <p>
          Beitr&auml;ge mit Kritik an Produkten, Firmen, Restaurants etc., es
          sei denn, der gesamte Vorgang wird sachlich vorgetragen und ist durch
          den jeweiligen Nutzer auch in vollem Umfang nachweisbar.
        </p>
        <p>
          Das Setzen von Links ist nur erlaubt, wenn diese zu gew&uuml;nschten
          Informationen im Sinne von Lokalpetition dienen.&Uuml;ber die
          Zul&auml;ssigkeit entscheiden wir im Einzelfall, sobald wir Kenntnis
          von einem Link erhalten.Da wir eine Haftung von unserer Seite f&uuml;r
          die von unseren Nutzern gesetzten Links nach heute geltender
          Rechtsprechung nicht mit v&ouml;lliger rechtlicher Sicherheit auch
          f&uuml;r die Zukunft ausschlie&szlig;en k&ouml;nnen, behalten wir uns
          vor, auch Links, die einmal zugelassen worden sind, zu einem
          sp&auml;teren Zeitpunkt ohne Angabe von Gr&uuml;nden jederzeit von
          unserer Seite zu entfernen.Die Nutzer, deren Links zugelassen worden
          sind, verpflichten sich, die Inhalte der gelinkten Seiten
          regelm&auml;&szlig;ig zu pr&uuml;fen und uns im Zweifel davon zu
          unterrichten, dass sich diese Inhalte ge&auml;ndert haben.Wir bitten
          alle Nutzer, uns auf etwaige unzul&auml;ssige Beitr&auml;ge, Links
          oder Etikett Verst&ouml;&szlig;e durch die Bet&auml;tigung der
          daf&uuml;r vorgesehenen Melde-buttons oder eine Mail an
          info@Lokalpetition.de hinzuweisen.
        </p>
        <p>
          4.2 Urheber- und Nutzungsrechte, gewerbliche Schutzrechte und
          Markenrechte, Haftung
        </p>
        <p>
          Alle Nutzer erkl&auml;ren sich damit einverstanden, dass Lokalpetition
          f&uuml;r die Plattform Lokalpetition.de von ihnen zur Verf&uuml;gung
          gestellten Daten (Texte) auch nach Einstellung der Nutzung durch den
          Nutzer noch f&uuml;r die Dauer des Bestehens des gesetzlichen
          Urheberrechtes weiterhin von Lokalpetition selbst oder durch
          Lokalpetition benannte Dritte f&uuml;r die Zwecke des Portalbetriebes
          elektronisch vervielf&auml;ltigt und zum Download (&sect; 19 UrhG)
          bereitgehalten werden d&uuml;rfen.Dar&uuml;ber hinaus darf
          Lokalpetition die Inhalte im Rahmen seines Newsletters per Mail an
          andere Nutzer versenden und Dritten gestatten, per RSS-Feed auf die
          Inhalte zur&uuml;ckzugreifen und diese auf ihren Internetseiten zum
          download anzubieten.Die Nutzer stehen daf&uuml;r ein, dass die von
          ihnen eingestellten bzw.zur Verf&uuml;gung gestellten Daten, wie
          vorstehend beschrieben, genutzt und ver&ouml;ffentlicht werden
          d&uuml;rfen. Schadensersatzanspr&uuml;che gegen Lokalpetition
          k&ouml;nnen nur geltend gemacht werden, wenn wir schuldhaft gegen
          unsere wesentlichen Vertragspflichten versto&szlig;en haben.Trifft uns
          nur ein sehr geringes Verschulden oder sind nur unwesentliche
          Nebenpflichten verletzt, schlie&szlig;en wir jede Haftung unsererseits
          aus, wobei Anspr&uuml;che nach dem Produkthaftungsgesetz
          unber&uuml;hrt bleiben.Der H&ouml;he nach sind alle etwaigen
          Schadensersatzanspr&uuml;che unserer Nutzer gegen uns beschr&auml;nkt
          auf den vorhersehbaren Schaden.Dies gilt nicht f&uuml;r Anspr&uuml;che
          aus dem Produkthaftungsgesetz sowie bei Verletzung von Leben,
          K&ouml;rper und Gesundheit.
        </p>
        <p>4.3 Umgangston und Netiquette</p>
        <p>
          Wir sind berechtigt, die Entscheidung &uuml;ber die Eignung von
          Beitr&auml;gen f&uuml;r uns zu treffen und auch berechtigt,
          Beitr&auml;ge ohne Angabe von Gr&uuml;nden zu entfernen.Alle Nutzer
          sind verpflichtet, sich in Umgangston und Netiquette an die
          Grundregeln der gegenseitigen Toleranz und des h&ouml;flichen Umgangs
          zu halten.Als solche setzen wir voraus: H&ouml;flichkeit &ndash;
          mindestens ein &bdquo;Hallo&ldquo;, &bdquo;Bitte&ldquo;,
          &bdquo;Danke&ldquo; und ein Gru&szlig; geh&ouml;ren zum Anstand.Keine
          Herabsetzungen oder Beleidigungen, im Zweifel noch einmal genau
          pr&uuml;fen und abw&auml;gen, was man geschrieben hat.Wer an einem
          echten Meinungsaustausch nicht teilnehmen m&ouml;chte, weil er
          z.B.darauf beharrt, dass seine Meinung die einzig wahre ist, sollte
          sich einen &ouml;ffentlichen Disput ersparen.Im Zweifel richtet man
          sich nach den Regeln der Gemeinschaft, insbesondere, wenn man ihr
          angeh&ouml;ren m&ouml;chte.Alle Herabsetzungen und pers&ouml;nlichen
          Angriffe werden auf Lokalpetition.de nicht toleriert, ungeachtet
          dessen, ob sich solche &Auml;u&szlig;erungen direkt gegen die anderen
          Nutzer, gegen Dritte oder gegen andere interne oder externe beteiligte
          oder unbeteiligte Personengruppen richten. Gleiches gilt f&uuml;r alle
          Beitr&auml;ge, die gegen geltendes Recht versto&szlig;en.
        </p>
        <p>
          <br />
        </p>
        <ol>
          <li>Moderation und Rechte</li>
          <li>
            Wir stellen die Einhaltung der Nutzungsbedingungen sicher, wenn
            n&ouml;tig auch durch das Sperren, oder L&ouml;schen von
            Beitr&auml;gen oder den Ausschluss von Mitgliedern.Diese
            Ma&szlig;nahmen werden im Sinne der Nutzungsbedingungen und im Sinne
            eines guten Forenklimas durchgef&uuml;hrt und unterliegen keinerlei
            Erkl&auml;rungspflicht.Wir tun dies im Interesse aller Nutzer.Es ist
            Lokalpetition infolge der Vielzahl von Kommunikationsvorg&auml;ngen
            und &ndash;angeboten nicht m&ouml;glich, diese vollst&auml;ndig zur
            Kenntnis zu nehmen.Wir bitten alle Nutzer, uns auf etwaige
            unseri&ouml;se oder ungesetzliche Verhaltensweisen durch die
            Bet&auml;tigung der daf&uuml;r vorgesehenen Meldebuttons und einer
            Mail an info@Lokalpetition.de hinzuweisen.
          </li>
          <li>Beendigung der Nutzung</li>
          <li>
            Jeder Nutzer kann die unentgeltliche Nutzungsm&ouml;glichkeit
            jederzeit ohne Angabe von Gr&uuml;nden beenden.Hierf&uuml;r sollte
            er sich nicht mehr einloggen oder den daf&uuml;r vorgesehenen
            Konto-l&ouml;schen-Button bet&auml;tigen und uns durch eine Mail an
            info@Lokalpetition.de darauf hinweisen. Eingestellte Inhalte und der
            Benutzername bleiben nach einer Beendigung nicht mehr Bestandteil
            des &ouml;ffentlich abrufbaren Inhaltsangebots bestehen.
          </li>
          <li>Datenschutz, Einwilligung des Nutzers</li>
          <li>
            Die von den Nutzern in das Benutzerkonto eingegebenen
            personenbezogenen Daten, bzw.die E-Mail Adresse, der Nutzername,
            Alter und Geschlecht werden von Lokalpetition.de nicht an Dritte
            weitergegeben.Die E-Mail-Adresse kann verwendet werden, um
            NutzerInnen in Bezug auf ihre Aktivit&auml;ten auf Lokalpetition.de
            zu kontaktieren.Das Nutzerkonto und der zugeh&ouml;rige Benutzername
            selbst k&ouml;nnen nicht entfernt oder ge&auml;ndert werden.Die
            vorgenannte Einwilligung kann jederzeit durch eine E-Mail an
            info@Lokalpetition.de widerrufen werden.
          </li>
          <li>&Auml;nderung</li>
          <li>
            Wir behalten uns das Recht vor, diese AGB von Zeit zu Zeit zu
            &uuml;berarbeiten, um Folgendes besser wiederzugeben:
          </li>
        </ol>
        <p>Gesetzes&auml;nderungen</p>
        <p>Neue regulatorische Anforderungen</p>
        <p>Verbesserungen oder Erweiterungen unserer Dienste.</p>
        <p>
          Wenn sich eine &Auml;nderung auf Ihre Nutzung der Dienste oder auf
          Ihre Rechte als Nutzer unserer Dienste auswirkt, benachrichtigen wir
          Sie vor dem Datum des Inkrafttretens der &Auml;nderung, indem wir eine
          E-Mail an die mit Ihrem Konto verkn&uuml;pfte E-Mail-Adresse schicken
          oder indem wir eine entsprechende Nachricht im Produkt selbst
          einblenden. Das Datum des Inkrafttretens der aktualisierten AGB liegt
          mindestens 30 Tage nach dem Datum der Benachrichtigung. Wenn Sie mit
          den &Auml;nderungen nicht einverstanden sind, m&uuml;ssen Sie Ihr
          Konto vor deren Inkrafttreten k&uuml;ndigen, indem Sie die Dienste
          nach Inkrafttreten der &Auml;nderungen weiterhin nutzen, stimmen Sie
          den ge&auml;nderten AGB zu.
        </p>
      </div>
    </div>
  );
}

export default Agb;
