
import { NavbarBottom } from "./NavbarBottom";



export const Report = () => {


	return (
		<div >
			<br /><br />
			<button className="btn btn-success btn-lg button"   >Melden</button>




			<NavbarBottom classstart="under-navitem-selected" classsearch="under-navitem-unselected"  classactivity="under-navitem-unselected" classprofile="under-navitem-unselected"/>
		</div>
	)

}