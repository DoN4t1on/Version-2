module.exports = {
  ////endPoint: 'http://localhost:5009/api',
  endPoint: 'https://app.lokalpetition.de/api',
  mapAPiKey: 'AIzaSyCkDkwcM-UT4Q6k5gfhFXeoN7JRAQek-PI',

  ImageEndPoint: 'https://app.lokalpetition.de/readfiles/',

  localToken: 'localpetition',
};

